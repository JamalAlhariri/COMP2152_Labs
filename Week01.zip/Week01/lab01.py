# Sample Coding Questions 01 Week 01
# Name: Jamal Alhariri


# Question 1: 
myArray = [1, 4, 7, 9]
print("Array values:", myArray)


# Question 2
a = 10
b = 2
c = 3
d = 4

e = (a - ((b ** c) // d)) + (a % c)
print("Result of expression:", e)


# Question 3

temperature = 32.6
print("The temperature today is: {:.3f} degrees Celsius".format(temperature))


# Question 4
addYears = 22
userAge = int(input("Enter your age: "))
userAge = userAge + addYears

print("Now showing the shop items filtered by age:", userAge)
